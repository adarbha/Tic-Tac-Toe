from setuptools import setup

setup(name = 'tictactoeadarbha',
      version = '0.1',
      description = 'Pieces for creating a TicTacToe Game',
      packages = ['tictactoeadarbha'],
      zip_safe = False)